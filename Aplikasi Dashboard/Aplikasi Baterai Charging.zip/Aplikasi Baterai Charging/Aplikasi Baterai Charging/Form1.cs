﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D; // Added for LinearGradientBrush
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Aplikasi_Baterai_Charging
{
    public partial class Form1 : Form
    {
        private SerialPort serialPort;
        private List<double> voltageReadings = new List<double>();
        private List<DateTime> timeReadings = new List<DateTime>();
        private int maxDataPoints = 100;
        private string logFilePath = "battery_log.csv";

        public Form1()
        {
            InitializeComponent();
            InitializeSerialPort();
            InitializeChart();
            InitializeTimer();
            // ApplyRoundedCorners(); - This method was missing, implementing it below

            // Set gradient background
            this.Paint += Form1_Paint;
        }

        // Added the missing ApplyRoundedCorners method
        private void ApplyRoundedCorners()
        {
            // Apply rounded corners to controls
            foreach (Control control in this.Controls)
            {
                if (control is GroupBox || control is Button)
                {
                    control.Region = System.Drawing.Region.FromHrgn(
                        CreateRoundRectRgn(0, 0, control.Width, control.Height, 10, 10));
                }
            }
        }

        // Required for ApplyRoundedCorners method to work
        [System.Runtime.InteropServices.DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int nLeftRect,
            int nTopRect,
            int nRightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse
        );

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Create a linear gradient brush for the form background
            Rectangle rect = new Rectangle(0, 0, this.Width, this.Height);
            using (LinearGradientBrush brush = new LinearGradientBrush(
                rect,
                Color.MediumAquamarine,
                Color.FromArgb(200, 240, 240), // Lighter color at bottom
                LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, rect);
            }
        }

        private void InitializeSerialPort()
        {
            serialPort = new SerialPort();
            serialPort.BaudRate = 57600;
            serialPort.DataReceived += SerialPort_DataReceived;

            // Populate the available COM ports
            string[] ports = SerialPort.GetPortNames();
            comboBoxPorts.Items.AddRange(ports);
            if (ports.Length > 0)
                comboBoxPorts.SelectedIndex = 0;
        }

        private void InitializeChart()
        {
            chart1.Series.Clear();
            chart1.ChartAreas[0].AxisX.LabelStyle.Format = "HH:mm:ss";
            chart1.ChartAreas[0].AxisX.Title = "Time";
            chart1.ChartAreas[0].AxisY.Title = "Voltage (V)";
            chart1.ChartAreas[0].AxisY.Minimum = 0;
            chart1.ChartAreas[0].AxisY.Maximum = 16.0; // Based on BUS_MAX_V from Arduino code

            // Enhance chart appearance
            chart1.ChartAreas[0].BackColor = Color.WhiteSmoke;
            chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.LightGray;
            chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.LightGray;
            chart1.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Segoe UI", 8);
            chart1.ChartAreas[0].AxisY.LabelStyle.Font = new Font("Segoe UI", 8);
            chart1.ChartAreas[0].AxisX.TitleFont = new Font("Segoe UI", 10, FontStyle.Bold);
            chart1.ChartAreas[0].AxisY.TitleFont = new Font("Segoe UI", 10, FontStyle.Bold);

            Series series = new Series("Voltage");
            series.ChartType = SeriesChartType.Spline; // Smoother line
            series.Color = Color.RoyalBlue;
            series.BorderWidth = 3;
            series.MarkerStyle = MarkerStyle.Circle;
            series.MarkerSize = 6;
            series.MarkerColor = Color.DarkBlue;
            chart1.Series.Add(series);

            // Set chart title with enhanced font
            Title title = new Title("Battery Voltage Over Time");
            title.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            title.ForeColor = Color.DarkSlateGray;
            chart1.Titles.Add(title);
        }

        private void InitializeTimer()
        {
            timer1.Interval = 1000; // 1 second
            timer1.Tick += timer1_Tick;
        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string data = serialPort.ReadLine().Trim();
                if (double.TryParse(data, out double voltage))
                {
                    // We need to use Invoke because we're updating UI from a different thread
                    this.Invoke(new Action(() => UpdateVoltageDisplay(voltage)));
                }
            }
            catch (Exception ex)
            {
                // Log or handle exception
                Console.WriteLine($"Error receiving data: {ex.Message}");
            }
        }

        private void UpdateVoltageDisplay(double voltage)
        {
            // Update the voltage display in the groupBox
            labelVoltage.Text = $"{voltage:F2} V";

            // Update battery state based on voltage
            UpdateBatteryState(voltage);

            // Add data point to our collections
            voltageReadings.Add(voltage);
            timeReadings.Add(DateTime.Now);

            // Limit data points to keep memory usage reasonable
            if (voltageReadings.Count > maxDataPoints)
            {
                voltageReadings.RemoveAt(0);
                timeReadings.RemoveAt(0);
            }

            // Update chart
            UpdateChart();
        }

        private void UpdateBatteryState(double voltage)
        {
            // Example battery state logic based on voltage
            string state;
            Color stateColor;

            if (voltage < 10.5)
            {
                state = "Low";
                stateColor = Color.Red;
            }
            else if (voltage < 12.5)
            {
                state = "Medium";
                stateColor = Color.Orange;
            }
            else if (voltage < 14.0)
            {
                state = "Good";
                stateColor = Color.Green;
            }
            else
            {
                state = "Charging";
                stateColor = Color.DodgerBlue;
            }

            labelState.Text = state;
            labelState.ForeColor = stateColor;

            // Update progress bar appearance based on state
            progressBarBattery.Value = CalculateBatteryPercentage(voltage);

            // Change progress bar color based on battery state
            if (progressBarBattery.Value < 20)
                progressBarBattery.ForeColor = Color.Red;
            else if (progressBarBattery.Value < 50)
                progressBarBattery.ForeColor = Color.Orange;
            else
                progressBarBattery.ForeColor = Color.Green;

            // Make voltage display more attractive
            labelVoltage.Text = $"{voltage:F2} V";
            labelVoltage.ForeColor = stateColor;
        }

        private int CalculateBatteryPercentage(double voltage)
        {
            // Simple conversion from voltage to percentage (adjust thresholds as needed)
            double minVoltage = 10.0;
            double maxVoltage = 14.0;
            double percentage = (voltage - minVoltage) / (maxVoltage - minVoltage) * 100;
            return Math.Min(100, Math.Max(0, (int)percentage));
        }

        private void UpdateChart()
        {
            chart1.Series[0].Points.Clear();

            for (int i = 0; i < voltageReadings.Count; i++)
            {
                chart1.Series[0].Points.AddXY(timeReadings[i], voltageReadings[i]);
            }

            chart1.Invalidate();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (serialPort.IsOpen)
            {
                // Disconnect
                timer1.Stop();
                serialPort.Close();
                btnConnect.Text = "Connect";
                lblStatus.Text = "Disconnected";
                comboBoxPorts.Enabled = true;
            }
            else
            {
                // Connect
                try
                {
                    serialPort.PortName = comboBoxPorts.SelectedItem.ToString();
                    serialPort.Open();
                    timer1.Start();
                    btnConnect.Text = "Disconnect";
                    lblStatus.Text = "Connected";
                    comboBoxPorts.Enabled = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error connecting to port: {ex.Message}", "Connection Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // This is used to update any UI elements that need regular updating
            // Most of our updates are driven by the SerialPort_DataReceived event
            // You could add code here to monitor connection status, etc.
        }

        private void SaveData()
        {
            try
            {
                // Create a SaveFileDialog to allow user to choose where to save the file
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
                saveFileDialog.Title = "Save Battery Data";
                saveFileDialog.DefaultExt = "csv";
                saveFileDialog.FileName = "battery_log.csv";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string selectedPath = saveFileDialog.FileName;

                    using (StreamWriter writer = new StreamWriter(selectedPath, false)) // false to overwrite
                    {
                        // Always write the header for new file
                        writer.WriteLine("Timestamp,Voltage");

                        // Write all current data points
                        for (int i = 0; i < voltageReadings.Count; i++)
                        {
                            writer.WriteLine($"{timeReadings[i]},{voltageReadings[i]:F2}");
                        }
                    }

                    // Update the logFilePath for future auto-saves if needed
                    logFilePath = selectedPath;

                    MessageBox.Show($"Data saved to {selectedPath}", "Save Successful",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving data: {ex.Message}", "Save Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ResetData()
        {
            voltageReadings.Clear();
            timeReadings.Clear();
            chart1.Series[0].Points.Clear();
            labelVoltage.Text = "-- V";
            labelState.Text = "--";
            progressBarBattery.Value = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Save As button
            SaveData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Reset button
            ResetData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Exit button
            if (serialPort.IsOpen)
            {
                serialPort.Close();
            }
            Application.Exit();
        }

        private void chart1_Click(object sender, EventArgs e)
        {
            // Optional: Add chart click behavior if needed
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Clean up when the form is closing
            if (serialPort != null && serialPort.IsOpen)
            {
                serialPort.Close();
            }
        }
    }
}